# freeCodeCamp - Back End Development and APIs

This is my path on [this NodeJS certification](https://www.freecodecamp.org/learn/back-end-development-and-apis/).

Please be aware that there is nothing here other than **spoilers**. After all, this is my solution to all the exercises
on this certification.

It took me two weeks on my free time to go through all the certification exercises.

Cheers.

Mário